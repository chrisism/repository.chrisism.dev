
INSERT INTO tags (id, tag) VALUES 
    ('2e1f3086c96b44d2a81f5c08876b4ef6', 'co-op'),
    ('de7bfaa72e924cd9a54ab5d225367b05', 'free-for-all'),
    ('4f64dabdb0f5430f94eca529d6049a13', 'turnbased'),
    ('1c67d7a0cccb47dfb1b36839a4bb1c1f', '4k'),
    ('ccd62da94f7a4bf4ba593670329c2690', '720'),
    ('bf62ca2ffb0347559b1a52ec70b0b189', '1080');