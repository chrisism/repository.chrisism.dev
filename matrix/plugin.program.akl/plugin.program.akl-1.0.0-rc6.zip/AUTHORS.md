## Advanced Kodi Launcher

**Advanced Kodi Launcher** was another (friendly) fork from Advanced Emulator Launcher 
version 0.10.0 in 2020 by [Chrisism](mailto:crizizz@gmail.com).  
AKL closely follows AEL, but focusses on being more modulair and being able to support 
different types of launcher applications.


**Advanced Emulator Launcher** was originally forked from Advanced Launcher 
version 2.5.8 on May 2016 by [Wintermute0110](mailto:wintermute0110@gmail.com). First
public released version of Advanced Emulator Launcher was 0.9.0 on Aug 2016.

[AEL Kodi forum thread](http://forum.kodi.tv/showthread.php?tid=287826)

AEL contributor list (in no particular order):

 * Chrisism

 * Paradix

 * Rufoo

## Advanced Launcher

**Advanced Launcher** was originally forked from Launcher by Angelscry. First version
of Advanced Launcher was released on November 2010. Other people credited in
Advanced Launcher are JustSomeUser, CinPoU, Leo212, Zerqent, Zosky, and Atsumori.

[AL Kodi forum thread](http://forum.kodi.tv/showthread.php?tid=85724)

## Launcher

**Launcher** was the original project that started it all. First Launcher version
was released on August 2008. Launcher was developed by JustSomeUser, CinPoU, 
Leo212, Zerqent and Zosky.

[Launcher Kodi forum thread](http://forum.kodi.tv/showthread.php?tid=35739)
