## Current
- Custom skin view for View ROM
- More details about addon plugins

## Previous
- Added support for PEGI rating
- Fixed bug deleting collections
- Proper icon/thumb mapping for virtual collections
- Virtual categories now render items from database
- Add and execute single instance ROMs or Games
- Added an overview option with installed plugins
- Fix adding tags to ROMs
- Minor bugfixes
- Updated dependency
- Fixed virtual collections (Favs, Most recent ..)
- Fixed scraping ROM assets only