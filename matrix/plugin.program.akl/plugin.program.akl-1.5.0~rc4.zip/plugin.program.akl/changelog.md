## Current
- Added extra field to metadata item
- Search term mode applicable for multi ROM scraping
- Refactoring of default asset mapping
- Added setting to disable view rendering notifications
- Changed database migrations system
- Added 'edit platform' to ROMs
- Changed platform can be applied to all ROMs in a collection
- AKL webservice port number can be changed through settings

## Previous
- Custom skin view for View ROM
- More details about addon plugins
- Fixed linking assets to wrong directory
- Fixed category rendering
- Added rebuild views option in settings dialog
- Added support for PEGI rating
- Fixed bug deleting collections