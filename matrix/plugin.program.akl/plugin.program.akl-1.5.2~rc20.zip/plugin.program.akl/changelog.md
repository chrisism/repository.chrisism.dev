## Current
- Fixed launching standalone sources
- Several fixes by mallexxx
- Moved default asset paths to edit assets/artwork menu

## Previous
- Separated launchers
- Implemented sources
- Search term mode applicable for multi ROM scraping
- Refactoring of default asset mapping
- Collections now use import rules from sources