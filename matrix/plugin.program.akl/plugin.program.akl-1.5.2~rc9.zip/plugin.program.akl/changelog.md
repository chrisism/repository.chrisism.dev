## Current
- Several fixes by mallexxx

## Previous
- Separated launchers
- Implemented sources
- Search term mode applicable for multi ROM scraping
- Refactoring of default asset mapping
- Collections now use import rules from sources