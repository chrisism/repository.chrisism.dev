# plugin.test.androidcmd
Test Android Commands with Kodi
