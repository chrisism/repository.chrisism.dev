# plugin.test.updateaddons
Test update addon source files in Kodi
