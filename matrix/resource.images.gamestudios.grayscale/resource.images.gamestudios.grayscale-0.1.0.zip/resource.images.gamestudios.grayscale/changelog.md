## v1.3.0
- Added ESRB flags and updated build script

## v1.2.0
- Moved image files one folder up because usage new builder script.

## v1.1.0
- More studio icons, credits to Rufoo.