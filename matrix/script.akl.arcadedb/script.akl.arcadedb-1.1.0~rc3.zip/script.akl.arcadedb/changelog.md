# Current
- Updated to work with new module version

# Previous
First official release of this ArcadeDB plugin for AKL.