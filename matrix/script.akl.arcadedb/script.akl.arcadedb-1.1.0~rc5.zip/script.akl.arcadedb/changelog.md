# Current
- Updated to work with new module version (sources)

# Previous
First official release of this ArcadeDB plugin for AKL.