# Advanced Kodi Launcher : Default plugins
## script.ael.defaults
Default launchers, scanners and scrapers for AKL.

| Release | Status |
|----|----|
| Stable | [![Build Status](https://dev.azure.com/jnpro/AKL/_apis/build/status/script.akl.defaults?branchName=main)](https://dev.azure.com/jnpro/AKL/_build/latest?definitionId=6&branchName=main)|

Default plugins made available for AKL.