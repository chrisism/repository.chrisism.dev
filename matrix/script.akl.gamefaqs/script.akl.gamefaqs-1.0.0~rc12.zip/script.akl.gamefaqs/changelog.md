## Current
- Fixed scraper
- Added metacritics
- Added nplayers and nplayers_online
- Added rating