## Current
- Support for sources (new module)
- Fixed scraper
- Added metacritics
- Added nplayers and nplayers_online
- Added rating