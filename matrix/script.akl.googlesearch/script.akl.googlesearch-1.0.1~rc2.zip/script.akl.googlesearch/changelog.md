## Current
- Fixed scraping by using Google API engine
## Previous
First official release of this Google search plugin for AKL.