## Current
- Added more system data from scanning
## Previous
First official release of this Nvidia gamestream plugins for AKL.