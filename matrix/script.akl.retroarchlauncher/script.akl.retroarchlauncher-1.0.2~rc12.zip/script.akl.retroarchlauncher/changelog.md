## Current
- Updated to support new args approach for executors.
- Fixed Android execution for Kodi Nexus.
  
## Previous releases
- Updated documentation.
- Optimized addon settings.
- Updated dependencies.
- Joystick system now suspendable.