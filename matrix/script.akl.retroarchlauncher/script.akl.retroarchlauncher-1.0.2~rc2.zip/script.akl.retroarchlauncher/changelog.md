## Current
- Updated documentation.
- Optimized addon settings.
- Updated dependencies.
- Joystick system now suspendable.

## v1.0.0
First official release of the Retroarchlauncher plugin for AKL.