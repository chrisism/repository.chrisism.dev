## Current
- Support for sources (new module)
- Updated to support new args approach for executors.
- Fixed Android execution for Kodi Nexus.
- Android storage issue fixes
  
## Previous releases
- Updated documentation.
- Optimized addon settings.
- Updated dependencies.
- Joystick system now suspendable.