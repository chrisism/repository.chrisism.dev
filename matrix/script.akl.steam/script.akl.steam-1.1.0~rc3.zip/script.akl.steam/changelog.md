## Current
- Added scraper
## Previous
First official release of this Steam plugin for AKL.