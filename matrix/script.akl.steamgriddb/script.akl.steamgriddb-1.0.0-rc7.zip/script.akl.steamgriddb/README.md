# script.akl.steamdb
SteamGridDB scraper plugin for AKL

| Release | Status |
|----|----|
| Stable |[![Build Status](https://dev.azure.com/jnpro/AKL/_apis/build/status/script.akl.steamgriddb?branchName=main)](https://dev.azure.com/jnpro/AKL/_build/latest?definitionId=12&branchName=main) |