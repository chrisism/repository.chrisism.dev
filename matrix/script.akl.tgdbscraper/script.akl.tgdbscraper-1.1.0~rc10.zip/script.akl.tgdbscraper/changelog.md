## Current
- Added update/refresh settings command
## Previous
- Added support for trailers
- Fix for ESRB ratings
- Updated dependencies