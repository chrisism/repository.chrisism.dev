# v1.0.1
First official release of the library module