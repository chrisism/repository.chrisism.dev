## Bug fixes
- Code fix for wizard dialogs.


## In previous releases
- Fix for scraper cache dirs.