## Bug fixes
- Code fix for wizard dialogs.

## Previous
- Fix for scraper cache dirs.