## Bug fixes
- Code fix for wizard dialogs.
- Updated HTTP calls to use requests module.

## In previous releases
- Fix for scraper cache dirs.