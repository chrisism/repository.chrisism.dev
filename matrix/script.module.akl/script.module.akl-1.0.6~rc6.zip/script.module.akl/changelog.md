## Bug fixes
- Code fix for wizard dialogs.
- Updated HTTP calls to use requests module.
- Support for joystick enable/disable when launching (#14)
- Use translated path for execution log files (#15)

## In previous releases
- Fix for scraper cache dirs.