# script.module.cryptography
Kodi addon for cryptography module. Contains the cryptography module and makes it accessible as an addon in Kodi.

Original repository: https://github.com/pyca/cryptography
Documentation: https://cryptography.io/en/latest/