# script.akl.googlesearch
Googlesearch asset scraping plugin for AKL

| Release | Status |
|----|----|
| Stable |[![Build Status](https://dev.azure.com/jnpro/AKL/_apis/build/status/script.akl.googlesearch?branchName=main)](https://dev.azure.com/jnpro/AKL/_build/latest?definitionId=15&branchName=main) |
