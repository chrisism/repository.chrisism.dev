# script.akl.steam
Steam Library scanner and launcher for AKL

| Release | Status |
|----|----|
| Stable |[![Build Status](https://dev.azure.com/jnpro/AKL/_apis/build/status/script.akl.steam?branchName=main)](https://dev.azure.com/jnpro/AKL/_build/latest?definitionId=10&branchName=main) |