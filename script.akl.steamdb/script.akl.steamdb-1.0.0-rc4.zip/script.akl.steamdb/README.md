# script.akl.steamdb
SteamDB scraper plugin for AKL

| Release | Status |
|----|----|
| Stable |[![Build Status](https://dev.azure.com/jnpro/AKL/_apis/build/status/script.akl.steamdb?branchName=main)](https://dev.azure.com/jnpro/AKL/_build/latest?definitionId=12&branchName=main) |