# TGDB scraper for Advanced Kodi Launcher
TGDB metadata and asset scraper for AKL

| Release | Status |
|----|----|
| Stable |[![Build Status](https://dev.azure.com/jnpro/AKL/_apis/build/status/script.akl.tgdbscraper?branchName=main)](https://dev.azure.com/jnpro/AKL/_build/latest?definitionId=8&branchName=main) |