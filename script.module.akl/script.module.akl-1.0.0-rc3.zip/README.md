# Advanced Kodi Launcher Module
## script.module.akl

| Release | Status |
|----|----|
| Stable | [![Build Status](https://dev.azure.com/jungerius/AKL/_apis/build/status/script.module.akl?branchName=main)](https://dev.azure.com/jungerius/AKL/_build/latest?definitionId=4&branchName=main)|